function [R T] = external_parameters_solve_vmmc(A, H)

inva = pinv(A);                     
x0 = [];
% 
for i=1:numel(H)
    h = H{i};                     
    
    %Rotation matrix estimation
    lamb = 1/norm(inva*h(:,1));
    r1 = lamb*inva*h(:,1);          % rotaton vector r1.
    r2 = lamb*inva*h(:,2);          % rotaton vector r2.
    r3 = cross(r1,r2);              % rotaton vector r3.
    
    %Orthogonality Enforcement    
    R_temp = [r1 r2 r3];
    [u,s,v] = svd(R_temp);
    Q{i} = u*v';
    
    %computation of the rotation matrix
    ang{i} = matrot_vmmc(Q{i});    
    R{i} = matrot_vmmc(ang{i});            
    R{i} = R{i}(1:3,1:3);
    
    % Translation Vector Estimation
    T{i} = lamb*inva*h(:,3);        % translation vector t.    
end